const { describeCases } = require("./ConfigTestCases.template");

describeCases({
	name: "ConfigTestCases"
});

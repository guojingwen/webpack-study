/** @type {import("../../../").Configuration} */
module.exports = {
	entry: "./index",
	devtool: "eval-cheap-module-source-map"
};

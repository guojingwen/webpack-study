/** @type {import("../../../").Configuration} */
module.exports = {
	entry: "./index"
};

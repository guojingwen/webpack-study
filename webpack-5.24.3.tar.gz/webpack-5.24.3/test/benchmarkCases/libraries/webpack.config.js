/** @type {import("../../../").Configuration} */
module.exports = {
	entry: ["react", "react-dom", "lodash"]
};

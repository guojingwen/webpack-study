/** @type {import("../../../../").Configuration} */
module.exports = {
	optimization: {
		noEmitOnErrors: true
	}
};

it("should compile with deprecations", () => {});

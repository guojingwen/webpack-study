it("should compile fine", () => {});

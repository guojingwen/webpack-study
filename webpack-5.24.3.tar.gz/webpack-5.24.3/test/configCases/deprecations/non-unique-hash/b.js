import { b } from "./module";

console.log(b);

import { a } from "./module";

console.log(a);

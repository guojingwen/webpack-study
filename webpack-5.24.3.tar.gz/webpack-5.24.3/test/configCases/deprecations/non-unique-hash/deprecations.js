module.exports = [{ code: /DEP_WEBPACK_MODULE_HASH/ }];

/** @type {import("../../../../").Configuration} */
module.exports = {
	optimization: {
		sideEffects: true,
		innerGraph: true
	}
};

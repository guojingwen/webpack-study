console.log("normal");

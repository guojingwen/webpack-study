module.exports = {
	findBundle: function () {
		return "./test.js";
	}
};

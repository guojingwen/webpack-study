module.hot.accept();

export default "-inner";

module.exports = [
	[/Loader error/]
]

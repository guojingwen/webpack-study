export default 1;
---
export default 2;
throw new Error("Failed");
---
export default 3;

export const value = 1;
---
export const value = 2;

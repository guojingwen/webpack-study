import { g } from "./shared";

expect(g()).toBe(42);

export function c() {
	return 42;
}

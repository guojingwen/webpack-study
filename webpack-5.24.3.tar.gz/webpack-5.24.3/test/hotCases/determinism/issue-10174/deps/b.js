export * from './c'

export function b() {
  // this extra export is needed for the issue to reproduce
}

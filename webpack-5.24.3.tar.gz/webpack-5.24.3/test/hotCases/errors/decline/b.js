export { default } from "./c"

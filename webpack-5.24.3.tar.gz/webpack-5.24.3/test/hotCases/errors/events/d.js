import e from "./e";
export default e;

if (module.hot) {
	module.hot.decline();
}

import g from "./g";
export default g;

if (module.hot) {
	module.hot.decline("./g");
}

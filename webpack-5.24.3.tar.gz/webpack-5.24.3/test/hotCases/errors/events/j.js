export default 1;
module.hot.accept();
---
export default 2;
throw new Error("Error while loading module j");

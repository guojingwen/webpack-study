import c from "./c";
export default c;

if (module.hot) {
	module.hot.accept("./c");
}

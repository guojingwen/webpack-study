export default 1;
---
export default 2;
throw new Error("Error while loading module h");

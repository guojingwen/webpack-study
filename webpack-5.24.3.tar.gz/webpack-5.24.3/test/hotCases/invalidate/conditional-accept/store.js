export let value1 = 0;
export function setValue1(v) {
	value1 = v;
}

export let value2 = 0;
export function setValue2(v) {
	value2 = v;
}

export function invalidate() {
	module.hot.invalidate();
}

export const value = {};

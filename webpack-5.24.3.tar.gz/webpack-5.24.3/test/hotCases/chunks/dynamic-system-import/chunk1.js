export { value } from "./file";
module.hot.accept("./file");

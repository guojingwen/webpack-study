export const abc = 40;
export const def = 41;
export const ghi = 42;

export { abc as default } from "./subject";
---
export { def as default } from "./subject";

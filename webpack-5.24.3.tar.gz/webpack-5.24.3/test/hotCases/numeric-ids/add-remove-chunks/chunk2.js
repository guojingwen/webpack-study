import { value as v } from "./file";

export const value = v + 0.5;

export { value } from "./file";

export var value = 1;
---
export var value = 1.5;
---
export var value = 3;

module.exports = {
	node: {
		__dirname: false
	}
};

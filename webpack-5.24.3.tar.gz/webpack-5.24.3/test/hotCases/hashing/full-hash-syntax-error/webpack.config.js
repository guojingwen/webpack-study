module.exports = {
	node: {
		__dirname: false
	},
	optimization: {
		emitOnErrors: false
	}
};

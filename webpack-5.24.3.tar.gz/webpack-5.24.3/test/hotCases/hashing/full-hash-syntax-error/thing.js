export default 1;
---
export default <<<<<<;
---
export default 1;
---
export default 2;

module.exports = {
	externals: {
		external: "var 'external'"
	}
};

module.exports = [[/Module parse failed/]];

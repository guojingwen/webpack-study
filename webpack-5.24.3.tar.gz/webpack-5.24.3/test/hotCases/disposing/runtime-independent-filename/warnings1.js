module.exports = [
	[
		/The configured output\.hotUpdateMainFilename doesn't lead to unique filenames per runtime/
	]
];

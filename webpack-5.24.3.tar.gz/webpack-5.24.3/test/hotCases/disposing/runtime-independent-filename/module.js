export default () => new Worker(new URL("./chunk2", import.meta.url));
---
export default 42;

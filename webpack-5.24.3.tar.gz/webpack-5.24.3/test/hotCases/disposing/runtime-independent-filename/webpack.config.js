/** @type {import("../../../../").Configuration} */
module.exports = {
	output: {
		hotUpdateMainFilename: "[hash].main-filename.json"
	}
};

export * from "./shared";
import.meta.webpackHot.accept("./shared");

export default import("./chunk2");
---
export default 42;

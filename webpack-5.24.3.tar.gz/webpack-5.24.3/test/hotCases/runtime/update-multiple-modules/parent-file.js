module.exports = require("./fileA") + require("./fileB");

module.exports = () => require("./a");
---
module.exports = () => require("./b");

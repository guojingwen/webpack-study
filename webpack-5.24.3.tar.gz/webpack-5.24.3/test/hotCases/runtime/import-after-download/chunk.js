import value from "./inner";

module.hot.accept("./inner");

export { value as default };

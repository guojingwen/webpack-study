export default import("./a");
---
export default import("./b");
---
export default import("./b");
---
export default import("./a");

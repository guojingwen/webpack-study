import "./a";
export default 1;
module.hot.accept("./a");
---
export default 2;

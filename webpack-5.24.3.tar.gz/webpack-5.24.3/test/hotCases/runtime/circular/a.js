import "./";
import "./b";
export default 1;
---
import "./";
import "./b";
export default 2;

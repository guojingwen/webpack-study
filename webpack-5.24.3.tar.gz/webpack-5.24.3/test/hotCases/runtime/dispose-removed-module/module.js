export { default as setHandler } from "./a";
---
import "./b"
---
export { default as default } from "./a";
export default import(/* webpackChunkName: "a" */ "./a");
---
export default import(/* webpackChunkName: "b" */ "./b");

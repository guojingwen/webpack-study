import {value} from "dep1";

export const val = value;

import.meta.webpackHot.accept("dep1");

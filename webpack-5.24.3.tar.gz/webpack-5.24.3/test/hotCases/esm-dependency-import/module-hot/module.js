import {value} from "dep1";

export const val = value;

module.hot.accept("dep1");

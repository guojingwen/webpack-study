import "./a";

export default "ok1";
---
import "./a";

export default "ok2";
